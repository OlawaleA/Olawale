// Paste the helpful function here:

// Now use the function to add elements to the list!
